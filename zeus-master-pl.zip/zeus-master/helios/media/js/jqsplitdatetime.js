$(function() {
   $(".datepicker").datepicker({ dateFormat: 'yy-mm-dd' });
});
