"""
Public Key Cryptography datatypes
"""
