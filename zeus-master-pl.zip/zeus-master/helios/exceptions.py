class VoterLimitReached(Exception):
    pass

class DuplicateVoterID(Exception):
    pass
