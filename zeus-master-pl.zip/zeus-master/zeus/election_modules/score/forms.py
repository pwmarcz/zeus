from zeus.forms import forms


class QuestionsForm(forms.QuestionsForm):
    pass
